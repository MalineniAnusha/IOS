//
//  MapViewExampleTests.m
//  MapViewExampleTests
//
//  Created by Paradigm Creatives on 9/11/14.
//  Copyright (c) 2014 paradigmcreatives. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface MapViewExampleTests : XCTestCase

@end

@implementation MapViewExampleTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
