//
//  STAppDelegate.h
//  MapViewExample
//
//  Created by Paradigm Creatives on 9/11/14.
//  Copyright (c) 2014 paradigmcreatives. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface STAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@end
