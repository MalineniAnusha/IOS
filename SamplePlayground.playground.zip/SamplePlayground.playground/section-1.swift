// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
let max_attempts=10
var firstValue="0"
firstValue="hello"
var x=0, y=0, z=0
var myString:String
myString="hello"
myString="hieeee"
print(myString)
println(myString)
print("First message is \(myString)")
println("this is the second message")
var a=5 ; println(a)
var variable=0
variable=10
var mixed=5+3.9898
let hexadecimalInteger = 0x11
let hexadecimalDouble = 0xFp3
let boolValue=true
if boolValue
{
    println("boolValue is true")
}
else
{
    println("boolValue is false")
}
let tuple=(233,"Anusha","PCS",22)
println(tuple.0)
print(tuple.1)
println(tuple.2)
print(tuple.3)
let (id,name,company,age)=tuple
println("id is \(id)")
var b=0.568
var c = Double(a)+b
let tuple1=(name:"Malineni" , id:233)
println(tuple1.name)
println(tuple1.1)
var s:String
s="789"
var t = s.toInt()
var v:String
v="xyz"
var u = v.toInt()
var j:String?="sailika"
j=nil
var h = 9
if t != nil {
    println("It has some value")
}
if t != nil {
    println("It has some value \(t)")
}
if t != nil {
    println("It has some value \(t!)")
}
if let k = s.toInt() {
    println("'\(s)\' has a value \(k)")
}






