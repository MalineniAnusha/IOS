//
//  ViewController.swift
//  DatePicker
//
//  Created by mac mini on 11/5/14.
//  Copyright (c) 2014 ParadigmCreatives. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var datelabel: UILabel!
    @IBOutlet weak var datepicker: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        datepicker.addTarget(self, action: Selector("selectedDateChanged:"), forControlEvents: UIControlEvents.ValueChanged)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    func selectedDateChanged(datepicker:UIDatePicker)
    {
    var dateformatter = NSDateFormatter()
    dateformatter.dateStyle = NSDateFormatterStyle.MediumStyle
    dateformatter.timeStyle = NSDateFormatterStyle.LongStyle
    
    var starDate = dateformatter.stringFromDate(datepicker.date)
    datelabel.text = starDate
    }

}

