//
//  STAppDelegate.h
//  ActionSheet
//
//  Created by Paradigm Creatives on 9/12/14.
//  Copyright (c) 2014 paradigmcreatives. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
