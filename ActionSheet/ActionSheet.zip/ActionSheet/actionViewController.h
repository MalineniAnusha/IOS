//
//  actionViewController.h
//  ActionSheet
//
//  Created by Paradigm Creatives on 9/12/14.
//  Copyright (c) 2014 paradigmcreatives. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface actionViewController : UIViewController <UIActionSheetDelegate>
- (IBAction)buttonaction:(id)sender;

@end
